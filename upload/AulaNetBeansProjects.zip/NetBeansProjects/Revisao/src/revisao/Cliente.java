/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* Modificadores de Acesso:
 privado - somente na própria classe
 protected - própria classe, filhos e para o psckage em geral
 public - liberado

 Final -  Atributo (constante) - 
 Classe: classe não pode mais ser herdada, quando não quer que haja variações da classe
 Método: não permite sobre escrita
 Static - Atributos e métodos são compartilhados
 Abstract - Classe não pode ser instanciada, somente herdada
 Método só pode ser criado em classe abstrata, não tem corpo e obriga a classe que herda a implementar o código

 Sobrescrita: mesmo assinatura só muda a implementação, classe filha sobrescrevendo método da mãe
 Sobrecarga: mesmo nome, assinaturas diferentes
 */
package revisao;

/**
 *
 * @author Aluno faculdade
 */
public abstract class Cliente {

    protected Cliente(String nome) {
        this.nome = nome;
    }

    public static int quantidadeClientes;

    protected String nome;
    protected int idade;
    protected float limite;
    static final float juros = 0.99f;

    public final void teste() {
    }

    public static float calcularValor(int valor) {
        //if(limite < valor)
        //       System.out.println("limite menor que o valor");
        return valor * (1 + juros);

    }

    @Override
    public String toString() {
        return "";
    }

    public abstract void comprar();
}

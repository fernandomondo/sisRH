/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package revisao;

/**
 *
 * @author Aluno faculdade
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Cliente c1 = new ClienteVIP("Manu");
        Cliente.quantidadeClientes = 10;
        Cliente.calcularValor(100);
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package revenda;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Aluno faculdade
 */
public class Menu {

    ArrayList<Veiculo> veiculos = new ArrayList<>();
    ArrayList<Marca> marcas = new ArrayList<>();
    ArrayList<Modelo> modelos = new ArrayList<>();
    int codigoVeiculo = 1;
    int codigoMarca = 1;
    int codigoModelo = 1;

    public void chamarMenu() {
        System.out.println("Sistema de revenda");
        System.out.println("1-cadastrar veiculo");
        System.out.println("2-listar veiculos");
        System.out.println("3-excluir veiculo");
        System.out.println("4-vender veiculo");
        System.out.println("5-cadastrar marca");
        System.out.println("6-listar marcas");
        System.out.println("7-excluir marca");
        System.out.println("8-cadastrar modelo");
        System.out.println("9-listar modelos");
        System.out.println("10-excluir modelo");
        System.out.println("11-sair");

        Scanner teclado = new Scanner(System.in);
        int opcao = teclado.nextInt();
        switch (opcao) {
            case 1:
                cadastrarVeiculo(teclado);
                break;
            case 2:
                /* chama metodo de listar*/
                break;

        }
        
        chamarMenu();
        
    }

    public void cadastrarVeiculo(Scanner teclado) {

        System.out.println("Digite o tipo do veiculo: 1 carro 2 moto");
        int tipo = teclado.nextInt();

        while (tipo != 1 && tipo != 2) {
            System.out.println("Opção inválida.");
            System.out.println("Digite o tipo do veiculo: 1 carro 2 moto");
            tipo = teclado.nextInt();
        }
        Veiculo veiculo;

        if (tipo == 1) {
            Carro c1 = new Carro();
            veiculo = c1;
            System.out.println("Digite o número de portas;");
            c1.setNumPortas(teclado.nextInt());
            System.out.println("Digite os opcionais:");
            c1.setOpcionais(teclado.nextLine());
        } else {
            Moto m1 = new Moto();
            veiculo = m1;
            System.out.println("Digite o número de cilindradas:");
            m1.setCilindradas(teclado.nextInt());
            System.out.println("Digite o estilo:");
            m1.setEstilo(teclado.nextLine());
        }
        veiculo.setTipo(tipo);
        System.out.println("Digite a marca:");
        String marcaDigitada = teclado.nextLine();
        for (Marca marca : marcas) {
            if (marcaDigitada.equals(marca.getNome())) {
                veiculo.setMarca(marca);
            }
        }

        System.out.println("Digite o modelo:");
        String modeloDigitado = teclado.nextLine();
        for (Modelo modelo : modelos) {
            if (modeloDigitado.equals(modelo.getNome())) {
                veiculo.setModelo(modelo);
            }
        }
        System.out.println("Digite o preço:");
        veiculo.setPreco(teclado.nextFloat());
        System.out.println("Digite o ano:");
        veiculo.setAno(teclado.nextInt());
        System.out.println("Disponível? 1(sim) 2(não) ");
        if (teclado.nextInt() == 1) {
            veiculo.setDisponivel(true);
        } else {
            veiculo.setDisponivel(false);
        }

        veiculo.setCodigo(codigoVeiculo++);
        veiculos.add(veiculo);
        System.out.println("Veículo cadastrado com sucesso!");    
        teclado.next();
    }
}
